const axios = require ('axios')
const url = "https://jsonplaceholder.typicode.com/posts"
const novoPost ={
    title: "Aprendendo integração o API",
    body: "Este é um exemplo de como fazer uma requiosição POST",
    userId: 1

}
axios.post(url,novoPost)
    .then(response =>{
        console.log("Recurso criado com sucesso: ")
        console.log(response.data)
    }
    )
    .catch(error =>{
        console.error(`Erro ao tentar criar o recurso: ${error}`)
    })